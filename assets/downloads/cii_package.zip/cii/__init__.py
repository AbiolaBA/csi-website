"""
Consumption Sovereignty Index (CSI)
=================================
A country-level, year-by-year measure of how well a nation's consumption
choices are aligned with its productive capability - the import-side mirror
of the Economic Complexity Index.

See CII_Methodology_v0.2.md for the full specification.
"""

__version__ = "0.2.0"
