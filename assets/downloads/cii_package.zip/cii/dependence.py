"""
cii/dependence.py
=================
Genuine import dependence and import-basket weights - Step 2 of the methodology.

    dep = max(0, (m - x) / (m + x))     net import ratio; 0 = not dependent
    w   = m / sum_p m                   share of the country-year import bill
"""
from __future__ import annotations

import pandas as pd


def add_dependence(df: pd.DataFrame) -> pd.DataFrame:
    """Add `dep` (net import ratio, >= 0) and `w` (import-basket weight)."""
    df = df.copy()
    denom = df["import_value"] + df["export_value"]
    net = df["import_value"] - df["export_value"]
    df["dep"] = (net / denom).where(denom > 0, 0.0).clip(lower=0.0)

    tot_m = df.groupby(["iso3", "year"], observed=True)["import_value"].transform("sum")
    df["w"] = (df["import_value"] / tot_m).where(tot_m > 0, 0.0)
    return df
