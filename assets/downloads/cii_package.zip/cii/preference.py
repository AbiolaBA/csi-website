"""
cii/preference.py
=================
CSI-Preference - within-good price-premium analysis (Move A).

For each (year, importer, HS6) computes the country's import unit value vs the
world-average export unit value for the same product. The country's import-
value-weighted premium across consumer goods is the macro fingerprint of paying
for foreign-brand prestige.

Yearly outputs cached in data/processed/_pref_y{YEAR}.parquet (idempotent — re-
runs skip years already computed). When all yearly files are present, --combine
assembles outputs/csi_preference_panel.{csv,parquet}.

    python -m cii.preference                # process all years (skip cached)
    python -m cii.preference --range 1995-2004
    python -m cii.preference --combine
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import duckdb
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
BACI_DIR = Path("/sessions/gracious-brave-sagan/mnt/Tier2 and Tier3 Data/BACI_HS92_V202501_unzip")
M49_MAP = BACI_DIR / "country_codes_V202501.csv"
OUT_DIR = ROOT / "outputs"
PROC_DIR = ROOT / "data" / "processed"
PREMIUM_CAP = 5.0
YEARS = list(range(1995, 2024))


def _bec_df():
    from cii import bec
    return pd.DataFrame([{"hs4": str(i).zfill(4), "end_use": bec.hs_enduse(str(i).zfill(4))}
                         for i in range(101, 9900)])


def process_year(year: int, con: duckdb.DuckDBPyConnection) -> pd.DataFrame | None:
    file = BACI_DIR / f"BACI_HS92_Y{year}_V202501.csv"
    if not file.exists():
        print(f"  skip {year}: file missing", flush=True)
        return None
    df = con.execute(f"""
        WITH yearly AS (
            SELECT j AS m49,
                   LPAD(CAST(k AS VARCHAR), 6, '0') AS hs6,
                   v AS value, q AS qty
            FROM read_csv_auto('{file.as_posix()}', header=True,
                               types={{'t':'INTEGER','i':'INTEGER','j':'INTEGER',
                                       'k':'VARCHAR','v':'DOUBLE','q':'DOUBLE'}})
            WHERE q > 0 AND v > 0
        ),
        country_flow AS (
            SELECT m49, hs6, SUM(value) AS c_v, SUM(qty) AS c_q
            FROM yearly GROUP BY m49, hs6
        ),
        world_flow AS (
            SELECT hs6, SUM(c_v) AS w_v, SUM(c_q) AS w_q
            FROM country_flow GROUP BY hs6
        ),
        joined AS (
            SELECT c.m49, c.hs6, c.c_v,
                   c.c_v/c.c_q AS c_uv, w.w_v/w.w_q AS w_uv,
                   (c.c_v/c.c_q - w.w_v/w.w_q) / NULLIF(w.w_v/w.w_q, 0) AS premium,
                   SUBSTR(c.hs6,1,4) AS hs4
            FROM country_flow c JOIN world_flow w USING (hs6)
            WHERE c.c_q > 0 AND w.w_q > 0
        ),
        tagged AS (
            SELECT j.*, COALESCE(b.end_use, 'X') AS end_use
            FROM joined j LEFT JOIN bec_hs4 b USING (hs4)
        )
        SELECT {year} AS year, m49,
               SUM(CASE WHEN end_use='C' AND ABS(premium)<{PREMIUM_CAP}
                        THEN c_v*premium ELSE 0 END)
                 / NULLIF(SUM(CASE WHEN end_use='C' AND ABS(premium)<{PREMIUM_CAP}
                                   THEN c_v ELSE 0 END), 0) AS premium_cons,
               SUM(CASE WHEN ABS(premium)<{PREMIUM_CAP} THEN c_v*premium ELSE 0 END)
                 / NULLIF(SUM(CASE WHEN ABS(premium)<{PREMIUM_CAP} THEN c_v ELSE 0 END), 0) AS premium_all,
               SUM(CASE WHEN end_use='C' THEN c_v ELSE 0 END) AS cons_imports,
               COUNT(DISTINCT CASE WHEN end_use='C' THEN hs6 END) AS n_cons_products
        FROM tagged GROUP BY m49
    """).df()
    return df


def combine() -> int:
    PROC_DIR.mkdir(parents=True, exist_ok=True)
    parts = sorted(PROC_DIR.glob("_pref_y*.parquet"))
    if not parts:
        print("[preference] no per-year parts to combine", file=sys.stderr)
        return 2
    print(f"[preference] combining {len(parts)} yearly parts ...", flush=True)
    panel = pd.concat([pd.read_parquet(p) for p in parts], ignore_index=True)
    cc = pd.read_csv(M49_MAP)
    panel["m49"] = panel["m49"].astype(int)
    panel = panel.merge(cc[["country_code","country_iso3"]]
                          .rename(columns={"country_code":"m49","country_iso3":"ISO3"}),
                          on="m49", how="left").dropna(subset=["ISO3"])
    panel = panel.rename(columns={"year":"Year"}).drop(columns=["m49"])
    panel["Year"] = panel["Year"].astype(int)
    panel["CSI_Pref_raw"] = -panel["premium_cons"]
    g = panel.groupby("Year")["CSI_Pref_raw"]
    panel["CSI_Pref"] = (panel["CSI_Pref_raw"] - g.transform("mean")) / g.transform("std")
    panel = panel[["ISO3","Year","premium_cons","premium_all","cons_imports",
                   "n_cons_products","CSI_Pref_raw","CSI_Pref"]].sort_values(["ISO3","Year"])
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    panel.to_csv(OUT_DIR / "csi_preference_panel.csv", index=False)
    panel.to_parquet(OUT_DIR / "csi_preference_panel.parquet", index=False)
    print(f"[preference] wrote {len(panel):,} country-years -> outputs/csi_preference_panel.*",
          flush=True)
    print(f"[preference] premium_cons mean={panel.premium_cons.mean():+.3f} "
          f"sd={panel.premium_cons.std():.3f}", flush=True)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--range", help="year range e.g. 1995-2004")
    ap.add_argument("--combine", action="store_true")
    args = ap.parse_args()
    if args.combine:
        return combine()
    if args.range:
        a, b = args.range.split("-")
        years = list(range(int(a), int(b) + 1))
    else:
        years = YEARS
    PROC_DIR.mkdir(parents=True, exist_ok=True)
    con = duckdb.connect()
    con.register("bec_hs4", _bec_df())
    for y in years:
        target = PROC_DIR / f"_pref_y{y}.parquet"
        if target.exists():
            print(f"  y{y}: cached", flush=True)
            continue
        df = process_year(y, con)
        if df is None: continue
        df.to_parquet(target, index=False)
        print(f"  y{y}: {len(df):,} rows -> {target.name}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
