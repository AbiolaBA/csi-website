"""
cii/tier3.py
============
Tier 3 - invert the CES allocation to recover alpha.

Uses the WDI extract (P_Data_Extract_From_World_Development_Indicators.xlsx):
  P_F : TM.UVI.MRCH.XD.WD  (Import unit value index, 2015 = 100)
  P_H : FP.CPI.TOTL        (Consumer price index, rebased to 2015 = 100)

alpha = kappa / (1 + kappa)
kappa = [s_F / (1 - s_F)] * (P_H / P_F)^(1 - eta)

Reports the headline alpha at eta = 1.5 and the sensitivity grid
{0.5, 1.0, 1.5, 2.0, 3.0}.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
EXT = Path("/sessions/gracious-brave-sagan/mnt/Tier2 and Tier3 Data")

WDI_FILE = EXT / "P_Data_Extract_From_World_Development_Indicators.xlsx"
TIER2_FILE = ROOT / "outputs" / "tier2_panel.parquet"
OUT_DIR = ROOT / "outputs"

ETA_GRID = [0.5, 1.0, 1.5, 2.0, 3.0]
ETA_HEAD = 1.5


def _parse_wdi(path: Path) -> pd.DataFrame:
    """Wide-format WDI extract -> long [ISO3, Year, series, value]."""
    d = pd.read_excel(path, sheet_name="Data")
    year_cols = [c for c in d.columns if isinstance(c, str) and c[:4].isdigit() and "YR" in c]
    long = d.melt(id_vars=["Country Code", "Series Code"], value_vars=year_cols,
                  var_name="ycol", value_name="value")
    long["Year"] = long["ycol"].str.extract(r"(\d{4})").astype(int)
    long["value"] = pd.to_numeric(long["value"], errors="coerce")
    return (long.rename(columns={"Country Code": "ISO3", "Series Code": "series"})
                 .dropna(subset=["value"])[["ISO3", "Year", "series", "value"]])


def invert_alpha(s_F: pd.Series, P_F: pd.Series, P_H: pd.Series, eta: float) -> pd.Series:
    if np.isclose(eta, 1.0):
        return s_F.clip(0.0, 1.0)
    s = s_F.clip(1e-6, 1 - 1e-6)
    ratio = s / (1.0 - s)
    valid = (P_H > 0) & (P_F > 0)
    price_term = (P_H / P_F).where(valid) ** (1.0 - eta)
    kappa = ratio * price_term
    return (kappa / (1.0 + kappa)).clip(0.0, 1.0)


def main() -> int:
    for p in (WDI_FILE, TIER2_FILE):
        if not p.exists():
            print(f"[tier3] missing input: {p}", file=sys.stderr)
            return 2

    print("[tier3] parsing WDI extract ...", flush=True)
    wdi = _parse_wdi(WDI_FILE)
    print(f"[tier3] WDI long rows: {len(wdi):,} | series: {wdi.series.nunique()}", flush=True)

    pf = wdi[wdi.series == "TM.UVI.MRCH.XD.WD"][["ISO3", "Year", "value"]].rename(columns={"value": "P_F"})
    ph_raw = wdi[wdi.series == "FP.CPI.TOTL"][["ISO3", "Year", "value"]].rename(columns={"value": "P_H_raw"})

    # rebase CPI to 2015 = 100 per country
    base = ph_raw[ph_raw.Year == 2015].set_index("ISO3")["P_H_raw"]
    ph = ph_raw.assign(P_H=ph_raw.apply(
        lambda r: 100.0 * r["P_H_raw"] / base[r["ISO3"]] if r["ISO3"] in base.index and base[r["ISO3"]] > 0 else np.nan,
        axis=1))[["ISO3", "Year", "P_H"]].dropna()

    print(f"[tier3] P_F rows: {len(pf):,} | P_H rows: {len(ph):,}", flush=True)

    t2 = pd.read_parquet(TIER2_FILE)[["ISO3", "Year", "s_F", "CSI_2", "CSI", "CSI_raw"]]
    panel = t2.merge(pf, on=["ISO3", "Year"], how="inner").merge(ph, on=["ISO3", "Year"], how="inner")
    print(f"[tier3] merged Tier-3 sample: {len(panel):,} country-years", flush=True)

    for eta in ETA_GRID:
        col = f"alpha_eta{int(round(eta*10)):02d}"
        panel[col] = invert_alpha(panel["s_F"], panel["P_F"], panel["P_H"], eta)

    panel["alpha"] = panel[f"alpha_eta{int(round(ETA_HEAD*10)):02d}"]
    panel["CSI_3_raw"] = 1.0 - panel["alpha"]
    g = panel.groupby("Year")["CSI_3_raw"]
    panel["CSI_3"] = (panel["CSI_3_raw"] - g.transform("mean")) / g.transform("std")

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    panel.to_csv(OUT_DIR / "tier3_panel.csv", index=False)
    panel.to_parquet(OUT_DIR / "tier3_panel.parquet", index=False)
    sens_cols = ["ISO3", "Year"] + [f"alpha_eta{int(round(e*10)):02d}" for e in ETA_GRID]
    panel[sens_cols].to_csv(OUT_DIR / "tier3_sensitivity.csv", index=False)

    print(f"[tier3] wrote {len(panel):,} country-years -> outputs/tier3_panel.*", flush=True)
    print(f"[tier3] alpha (eta=1.5) mean={panel.alpha.mean():.3f} sd={panel.alpha.std():.3f}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
