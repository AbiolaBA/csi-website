"""
cii/bec.py
==========
End-use classification of traded goods - splitting products into FINAL
CONSUMPTION goods and the rest (intermediate / primary / capital).

This is a transparent, rule-based classification built on the logic of the UN
Classification by Broad Economic Categories (BEC) Rev.5: a chapter/section-level
default, plus explicit overrides for the heading codes whose end-use differs
from their chapter. It is deliberately readable so it can be reviewed line by
line and corrected; it can later be swapped for the official UNSD HS-BEC
correspondence table.

End-use codes:  'C' final consumption  |  'I' intermediate / primary  |
                'K' capital  |  'X' special / excluded
"""
from __future__ import annotations

import pandas as pd

# --- HS 1992: 2-digit chapter default end-use --------------------------------
_HS_CHAPTER = {
    1: 'I', 2: 'C', 3: 'C', 4: 'C', 5: 'I', 6: 'I', 7: 'C', 8: 'C', 9: 'C', 10: 'I',
    11: 'C', 12: 'I', 13: 'I', 14: 'I', 15: 'C', 16: 'C', 17: 'C', 18: 'C', 19: 'C', 20: 'C',
    21: 'C', 22: 'C', 23: 'I', 24: 'C', 25: 'I', 26: 'I', 27: 'I', 28: 'I', 29: 'I', 30: 'C',
    31: 'I', 32: 'I', 33: 'C', 34: 'C', 35: 'I', 36: 'I', 37: 'C', 38: 'I', 39: 'I', 40: 'I',
    41: 'I', 42: 'C', 43: 'C', 44: 'I', 45: 'I', 46: 'C', 47: 'I', 48: 'I', 49: 'C', 50: 'I',
    51: 'I', 52: 'I', 53: 'I', 54: 'I', 55: 'I', 56: 'I', 57: 'C', 58: 'I', 59: 'I', 60: 'I',
    61: 'C', 62: 'C', 63: 'C', 64: 'C', 65: 'C', 66: 'C', 67: 'C', 68: 'I', 69: 'I', 70: 'I',
    71: 'I', 72: 'I', 73: 'I', 74: 'I', 75: 'I', 76: 'I', 78: 'I', 79: 'I', 80: 'I', 81: 'I',
    82: 'I', 83: 'I', 84: 'K', 85: 'I', 86: 'K', 87: 'I', 88: 'K', 89: 'K', 90: 'I',
    91: 'C', 92: 'C', 93: 'I', 94: 'C', 95: 'C', 96: 'C', 97: 'C',
}
# --- HS 1992: 4-digit heading overrides (end-use differs from the chapter) ----
_HS_OVERRIDE = {
    '3924': 'C', '3926': 'C',                                        # plastic household ware
    '4419': 'C', '4420': 'C',                                        # wood household ware
    '4817': 'C', '4818': 'C', '4820': 'C',                           # consumer paper articles
    '6911': 'C', '6912': 'C', '6913': 'C', '6914': 'C',              # ceramic tableware/ornaments
    '7013': 'C',                                                     # glass tableware
    '7113': 'C', '7114': 'C', '7116': 'C', '7117': 'C',              # jewellery / imitation
    '7321': 'C', '7323': 'C',                                        # iron/steel household ware
    '8211': 'C', '8212': 'C', '8213': 'C', '8214': 'C', '8215': 'C', # cutlery
    '8306': 'C',                                                     # base-metal ornaments
    '8415': 'C', '8418': 'C', '8450': 'C', '8452': 'C',              # household machinery
    '8508': 'C', '8509': 'C', '8510': 'C', '8513': 'C', '8516': 'C', # consumer electricals
    '8517': 'C', '8518': 'C', '8519': 'C', '8521': 'C', '8527': 'C', '8528': 'C',
    '8703': 'C', '8711': 'C', '8712': 'C', '8715': 'C',              # consumer vehicles
    '9003': 'C', '9004': 'C', '9005': 'C', '9006': 'C', '9007': 'C', # consumer optics/cameras
    '9406': 'K',                                                     # prefab buildings -> capital
}

# --- SITC Rev.2 --------------------------------------------------------------
_SITC_SECTION = {0: 'C', 1: 'C', 2: 'I', 3: 'I', 4: 'I', 5: 'I', 6: 'I', 7: 'K', 8: 'C', 9: 'X'}
_SITC_DIV_OVERRIDE = {            # 2-digit division
    '00': 'I', '04': 'I', '08': 'I',   # live animals; cereals; animal feed
    '54': 'C', '55': 'C',              # pharmaceuticals; perfumery/cosmetics/cleaning
    '76': 'C',                         # telecom & sound-reproducing apparatus
    '87': 'I',                         # professional/scientific instruments
}
_SITC_GRP_OVERRIDE = {            # 3-digit group
    '659': 'C', '665': 'C', '666': 'C',   # floor coverings; glassware; pottery
    '775': 'C',                           # household-type equipment
    '781': 'C', '785': 'C',               # passenger cars; cycles & motorcycles
}


def _norm(code, width: int = 4) -> str:
    s = str(code).strip()
    if s.endswith('.0'):
        s = s[:-2]
    return s.zfill(width)


def hs_enduse(code) -> str:
    c = _norm(code, 4)
    if c in _HS_OVERRIDE:
        return _HS_OVERRIDE[c]
    try:
        return _HS_CHAPTER.get(int(c[:2]), 'I')
    except ValueError:
        return 'I'


def sitc_enduse(code) -> str:
    c = _norm(code, 4)
    if c[:3] in _SITC_GRP_OVERRIDE:
        return _SITC_GRP_OVERRIDE[c[:3]]
    if c[:2] in _SITC_DIV_OVERRIDE:
        return _SITC_DIV_OVERRIDE[c[:2]]
    try:
        return _SITC_SECTION.get(int(c[0]), 'I')
    except ValueError:
        return 'I'


def enduse(code, classification: str) -> str:
    return hs_enduse(code) if classification == 'hs92' else sitc_enduse(code)


def filter_consumption(df: pd.DataFrame, classification: str) -> pd.DataFrame:
    """Keep only the rows whose product is a final consumption good."""
    fn = hs_enduse if classification == 'hs92' else sitc_enduse
    col = df['product']
    cats = list(col.cat.categories) if hasattr(col, 'cat') else col.astype(str).unique()
    keep = [c for c in cats if fn(c) == 'C']
    return df[df['product'].isin(keep)].copy()


def classification_table(codes, classification: str) -> pd.DataFrame:
    """A reviewable table: every product code with its assigned end-use."""
    fn = hs_enduse if classification == 'hs92' else sitc_enduse
    rows = [{'classification': classification, 'product': str(c),
             'end_use': fn(c), 'is_consumption': fn(c) == 'C'}
            for c in sorted(set(str(x) for x in codes))]
    return pd.DataFrame(rows)
