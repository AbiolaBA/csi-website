"""
cii/capability.py
=================
Capability score - Step 1, methodology v0.3.

v0.2 used density alone (cap = 1 - distance). Verification showed that lets
commodity economies escape: an economy that exports almost nothing sits 'far'
from every product, so its measured capability was ~0 everywhere and it could
never register a gap.

v0.3 makes capability complexity-aware. A product simple enough that almost any
economy with labour and a domestic market can make it should count as 'within
capability' for everyone; only genuinely complex products still require revealed
proximity. So:

    simplicity_p = 1 - percentile_rank(PCI_p)     (per year, over all products)
    density_cp   = 1 - distance_cp
    cap_cp       = max(simplicity_p, density_cp)
"""
from __future__ import annotations

import pandas as pd


def add_capability(df: pd.DataFrame) -> pd.DataFrame:
    """Add density, simplicity and cap (= max of the two), all in [0, 1]."""
    df = df.copy()
    df["density"] = (1.0 - df["distance"]).clip(0.0, 1.0)

    # product complexity -> simplicity, ranked once per (year, product)
    pp = df[["year", "product", "pci"]].drop_duplicates(["year", "product"]).copy()
    pp["simplicity"] = 1.0 - pp.groupby("year")["pci"].rank(pct=True)
    df = df.merge(pp[["year", "product", "simplicity"]], on=["year", "product"], how="left")
    df["simplicity"] = df["simplicity"].fillna(0.0).clip(0.0, 1.0)

    df["cap"] = df[["density", "simplicity"]].max(axis=1)
    return df
