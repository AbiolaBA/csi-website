#!/usr/bin/env python3
"""
cii/download.py
================
Download the Harvard Growth Lab - Atlas of Economic Complexity trade datasets
from the Harvard Dataverse, for the Consumption Sovereignty Index pipeline.

WHERE TO RUN THIS
-----------------
Run it on a normal internet connection (your own computer). It needs no
third-party packages - only the Python standard library.

    python cii/download.py             # list, confirm, then download
    python cii/download.py --list      # just list the files and their sizes
    python cii/download.py --yes       # download without the confirmation prompt
    python cii/download.py --match country_country   # only matching filenames

Files land in  data/raw/sitc/  and  data/raw/hs92/ , and the exact data
vintage is recorded in  data/raw/manifest.json  for replicability.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

DATAVERSE = "https://dataverse.harvard.edu"
TIMEOUT = 60
UA = {"User-Agent": "CII-pipeline/0.2"}

# Dataset DOIs - these mirror config.yaml -> sources. They rarely change.
SOURCES = {
    "sitc": {"doi": "doi:10.7910/DVN/H8SFD2", "label": "Atlas trade data - SITC Rev. 2"},
    "hs92": {"doi": "doi:10.7910/DVN/T4CHWJ", "label": "Atlas trade data - HS 1992"},
}

ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "data" / "raw"


def _get_json(url: str) -> dict:
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=TIMEOUT) as r:
        return json.loads(r.read().decode("utf-8"))


def human(n: float) -> str:
    x = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if x < 1024 or unit == "TB":
            return f"{x:,.1f} {unit}"
        x /= 1024


def list_files(doi: str):
    """Return (file_records, version_string) for a dataset's latest version."""
    url = f"{DATAVERSE}/api/datasets/:persistentId/?persistentId={doi}"
    version = _get_json(url)["data"]["latestVersion"]
    records = []
    for f in version.get("files", []):
        df = f.get("dataFile", {})
        records.append({
            "id": df.get("id"),
            "filename": df.get("originalFileName") or df.get("filename"),
            "size": df.get("originalFileSize") or df.get("filesize") or 0,
        })
    vstr = f"{version.get('versionNumber')}.{version.get('versionMinorNumber')}"
    return records, vstr


def download_file(file_id: int, dest: Path) -> int:
    """Stream one datafile to disk. Tries the original format, then plain."""
    last_err = None
    for suffix in ("?format=original", ""):
        url = f"{DATAVERSE}/api/access/datafile/{file_id}{suffix}"
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                total = int(resp.headers.get("Content-Length", 0))
                done, t0 = 0, time.time()
                tmp = dest.with_suffix(dest.suffix + ".part")
                with open(tmp, "wb") as fh:
                    while True:
                        buf = resp.read(1 << 20)  # 1 MB chunks
                        if not buf:
                            break
                        fh.write(buf)
                        done += len(buf)
                        msg = f"{100*done/total:5.1f}%  ({human(done)})" if total else human(done)
                        sys.stdout.write(f"\r    {dest.name}: {msg}")
                        sys.stdout.flush()
                tmp.rename(dest)
                sys.stdout.write(f"\r    {dest.name}: done ({human(done)} in {time.time()-t0:.0f}s)\n")
                return done
        except urllib.error.HTTPError as e:
            last_err = e
            continue
    raise last_err if last_err else RuntimeError("download failed")


def main() -> int:
    ap = argparse.ArgumentParser(description="Download Atlas trade data from Harvard Dataverse.")
    ap.add_argument("--list", action="store_true", help="list files and sizes only")
    ap.add_argument("--yes", action="store_true", help="skip the confirmation prompt")
    ap.add_argument("--match", default="", help="only files whose name contains this text")
    args = ap.parse_args()

    manifest = {"downloaded_utc": datetime.now(timezone.utc).isoformat(),
                "dataverse": DATAVERSE, "datasets": {}}
    plan = []  # list of (source_key, file_record)

    print("Querying the Harvard Dataverse ...\n")
    for key, src in SOURCES.items():
        try:
            files, vstr = list_files(src["doi"])
        except urllib.error.URLError as e:
            print(f"  ! Could not reach the Dataverse for '{key}': {e}")
            print("    Check your internet connection, or download the files manually")
            print("    (see data/HOW_TO_GET_THE_DATA.md).")
            return 2
        if args.match:
            files = [f for f in files if args.match.lower() in (f["filename"] or "").lower()]
        manifest["datasets"][key] = {"doi": src["doi"], "version": vstr,
                                     "files": [{"filename": f["filename"], "size": f["size"]}
                                               for f in files]}
        print(f"  {src['label']}  ({src['doi']}, version {vstr})")
        for f in files:
            print(f"     - {(f['filename'] or '?'):<52} {human(f['size'])}")
            plan.append((key, f))
        print()

    total = sum(f["size"] for _, f in plan)
    print(f"Total: {len(plan)} file(s), {human(total)}.\n")
    if args.list:
        return 0
    if not plan:
        print("Nothing to download (check the --match filter).")
        return 0
    if not args.yes:
        if input("Proceed with download? [y/N] ").strip().lower() not in ("y", "yes"):
            print("Aborted.")
            return 0

    for key, f in plan:
        dest_dir = RAW_DIR / key
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / f["filename"]
        if dest.exists() and f["size"] and dest.stat().st_size == f["size"]:
            print(f"    {dest.name}: already present, skipping")
            continue
        try:
            download_file(f["id"], dest)
        except (urllib.error.URLError, RuntimeError) as e:
            print(f"\n  ! Failed to download {f['filename']}: {e}")
            return 2

    RAW_DIR.mkdir(parents=True, exist_ok=True)
    (RAW_DIR / "manifest.json").write_text(json.dumps(manifest, indent=2))
    print(f"\nDone. Raw files are in {RAW_DIR}")
    print("Data vintage recorded in data/raw/manifest.json")
    print("\nNext: add the BEC correspondence file (see data/HOW_TO_GET_THE_DATA.md),")
    print("then tell Claude the data is ready so the pipeline build can continue.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
