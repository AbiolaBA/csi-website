"""
cii/tier2.py
============
Tier 2 - apparent consumption and the foreign expenditure share.

Adapted to the user's actual data (in mounted folder "Tier2 and Tier3 Data"):
  - UNIDO INDSTAT 2 data.csv  (ISIC Rev. 4, M.49 country codes, ValueUSD column)
  - BACI country_codes_V202501.csv  (M.49 -> ISO3 map)

s_F = consumption_imports / (Y_C + consumption_imports - consumption_exports)

where Y_C is INDSTAT manufacturing output (in USD) summed over the consumption-
good ISIC Rev. 4 divisions {10, 11, 12, 13, 14, 15, 21, 22, 27, 29, 31, 32}.

The HS-ISIC concordance the user supplied was a corrupted PDF, so we skip the
concordance step and identify consumption-good ISIC industries directly.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
EXT = Path("/sessions/gracious-brave-sagan/mnt/Tier2 and Tier3 Data")

INDSTAT_FILE = EXT / "data.csv"
M49_MAP_FILE = EXT / "BACI_HS92_V202501_unzip" / "country_codes_V202501.csv"
TIER1_FILE = ROOT / "data" / "processed" / "_csi_global_panel.parquet"
OUT_DIR = ROOT / "outputs"

# ISIC Rev. 4 manufacturing divisions that are predominantly consumption-good producers
ISIC4_CONSUMPTION = {"10", "11", "12", "13", "14", "15", "21", "22", "27", "29", "31", "32"}


def main() -> int:
    for p in (INDSTAT_FILE, M49_MAP_FILE, TIER1_FILE):
        if not p.exists():
            print(f"[tier2] missing input: {p}", file=sys.stderr)
            return 2

    print("[tier2] loading INDSTAT ...", flush=True)
    d = pd.read_csv(INDSTAT_FILE, low_memory=False)
    print(f"[tier2] INDSTAT rows: {len(d):,}  (Output rows: {(d.Variable=='Output').sum():,})", flush=True)

    d = d[d["Variable"] == "Output"].copy()
    d["act"] = d["ActivityCode"].astype(str).str.strip()
    d = d[d["act"].isin(ISIC4_CONSUMPTION)]
    d["ValueUSD"] = pd.to_numeric(d["ValueUSD"], errors="coerce")
    d["m49"] = d["CountryCode"].astype(str).str.zfill(3)
    d["Year"] = pd.to_numeric(d["Year"], errors="coerce").astype("Int64")
    d = d.dropna(subset=["ValueUSD", "Year"])

    Y = (d.groupby(["m49", "Year"], as_index=False)["ValueUSD"].sum()
           .rename(columns={"ValueUSD": "Y_C"}))
    print(f"[tier2] consumption-ISIC output rows aggregated: {len(Y):,}", flush=True)

    cc = pd.read_csv(M49_MAP_FILE)
    cc["m49"] = cc["country_code"].astype(str).str.zfill(3)
    Y = Y.merge(cc[["m49", "country_iso3"]].rename(columns={"country_iso3": "ISO3"}),
                on="m49", how="left").dropna(subset=["ISO3"])
    Y["Year"] = Y["Year"].astype(int)
    print(f"[tier2] mapped to ISO3: {Y.ISO3.nunique()} countries, {Y.Year.min()}-{Y.Year.max()}", flush=True)

    t1 = pd.read_parquet(TIER1_FILE)
    if "cons_imp" not in t1.columns:
        t1 = t1.assign(cons_imp=t1["cons_imp_share"] * t1["tot_imp"],
                       cons_exp=t1["cons_exp_share"] * t1["tot_exp"])

    panel = Y.merge(t1[["ISO3", "Year", "cons_imp", "cons_exp", "tot_imp", "tot_exp",
                        "CSI", "CSI_raw"]], on=["ISO3", "Year"], how="inner")
    panel["apparent_C"] = panel["Y_C"] + panel["cons_imp"] - panel["cons_exp"]
    panel["s_F"] = (panel["cons_imp"] / panel["apparent_C"].where(panel["apparent_C"] > 0)).clip(0.0, 1.0)
    panel["CSI_2_raw"] = 1.0 - panel["s_F"]
    g = panel.groupby("Year")["CSI_2_raw"]
    panel["CSI_2"] = (panel["CSI_2_raw"] - g.transform("mean")) / g.transform("std")
    panel = panel[["ISO3", "Year", "Y_C", "cons_imp", "cons_exp", "apparent_C",
                   "s_F", "CSI_2_raw", "CSI_2", "CSI", "CSI_raw"]].sort_values(["ISO3", "Year"])

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    panel.to_csv(OUT_DIR / "tier2_panel.csv", index=False)
    panel.to_parquet(OUT_DIR / "tier2_panel.parquet", index=False)
    print(f"[tier2] wrote {len(panel):,} country-years | "
          f"{panel.ISO3.nunique()} countries | "
          f"years {panel.Year.min()}-{panel.Year.max()}", flush=True)
    print(f"[tier2] s_F mean={panel.s_F.mean():.3f} sd={panel.s_F.std():.3f} "
          f"range [{panel.s_F.min():.3f}, {panel.s_F.max():.3f}]", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
