"""
cii/run.py
==========
Run the full Consumption Sovereignty Index pipeline (methodology v0.3).

    python -m cii.run                              # all classifications & variants
    python -m cii.run --only hs92 --variant consumption_only
    python -m cii.run --combine                    # assemble outputs from parts

Outputs (outputs/): cii_panel.csv/.parquet, cii_ranking.csv,
cii_product_diagnostics.csv.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
import yaml

from . import bec, capability, clean, dependence
from . import index as idx

ROOT = Path(__file__).resolve().parent.parent


def _cfg() -> dict:
    return yaml.safe_load(open(ROOT / "config.yaml", encoding="utf-8"))


def process_one(cls: str, variant: str, min_trade: float) -> pd.DataFrame:
    """Clean -> capability -> (consumption filter) -> dependence -> index."""
    print(f"[{cls}/{variant}] loading and cleaning ...", flush=True)
    df = clean.load_clean(cls, min_total_trade_usd=min_trade)
    df = capability.add_capability(df)
    if variant == "consumption_only":
        df = bec.filter_consumption(df, cls)
    print(f"[{cls}/{variant}] {len(df):,} country-product-year rows", flush=True)
    df = dependence.add_dependence(df)

    panel = idx.compute_index(df)
    panel.insert(0, "classification", cls)
    panel.insert(1, "variant", variant)
    diag = idx.product_diagnostics(df)
    diag.insert(0, "classification", cls)
    diag.insert(1, "variant", variant)

    proc = ROOT / "data" / "processed"
    proc.mkdir(parents=True, exist_ok=True)
    panel.to_parquet(proc / f"_panel_{cls}_{variant}.parquet", index=False)
    diag.to_parquet(proc / f"_diag_{cls}_{variant}.parquet", index=False)
    print(f"[{cls}/{variant}] {len(panel):,} country-years scored", flush=True)
    return panel


def combine() -> pd.DataFrame:
    """Assemble final outputs from the per-classification/variant parts."""
    cfg = _cfg()
    proc = ROOT / "data" / "processed"
    out = ROOT / cfg["paths"]["output_dir"]
    out.mkdir(parents=True, exist_ok=True)
    hubs = set(cfg["reexport_hubs"]["iso3"])

    panels, diags = [], []
    for cls in cfg["index"]["classifications"]:
        for var in cfg["index"]["variants"]:
            pp = proc / f"_panel_{cls}_{var}.parquet"
            dp = proc / f"_diag_{cls}_{var}.parquet"
            if pp.exists():
                panels.append(pd.read_parquet(pp))
            if dp.exists():
                diags.append(pd.read_parquet(dp))
    if not panels:
        raise SystemExit("no processed parts found - run without --combine first")

    panel = pd.concat(panels, ignore_index=True)
    diag = pd.concat(diags, ignore_index=True)
    panel["is_reexport_hub"] = panel["iso3"].isin(hubs)

    keys = ["classification", "variant", "year"]
    main = panel[~panel["is_reexport_hub"]].sort_values(
        keys + ["CII"], ascending=[True, True, True, False]).copy()
    main["rank"] = main.groupby(keys).cumcount() + 1
    hub = panel[panel["is_reexport_hub"]].copy()
    hub["rank"] = pd.NA
    ranking = pd.concat([main, hub], ignore_index=True)

    panel.to_csv(out / "cii_panel.csv", index=False)
    panel.to_parquet(out / "cii_panel.parquet", index=False)
    ranking.to_csv(out / "cii_ranking.csv", index=False)
    diag.to_csv(out / "cii_product_diagnostics.csv", index=False)
    print(f"\nwritten to {out}/  ({len(panel):,} country-years)")
    return panel


def run(only: str | None = None, variant: str | None = None) -> None:
    cfg = _cfg()
    min_trade = float(cfg["filters"]["min_total_trade_usd"])
    classes = [only] if only else cfg["index"]["classifications"]
    variants = [variant] if variant else cfg["index"]["variants"]
    for cls in classes:
        for var in variants:
            process_one(cls, var, min_trade)
    if not only and not variant:
        combine()


def main() -> int:
    ap = argparse.ArgumentParser(description="Run the CII pipeline.")
    ap.add_argument("--only", choices=["hs92", "sitc"])
    ap.add_argument("--variant", choices=["all_merchandise", "consumption_only"])
    ap.add_argument("--combine", action="store_true")
    args = ap.parse_args()
    if args.combine:
        combine()
    else:
        run(only=args.only, variant=args.variant)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
