"""
cii/clean.py
============
Load and clean the Atlas country-product-year trade data for one classification.

All heavy work (CSV scan, coverage filters) is done inside DuckDB so it streams
out-of-core and stays fast. Returns a tidy, compact country-product-year frame.
"""
from __future__ import annotations

from pathlib import Path

import duckdb
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent

_CODE_COL = {"hs92": "product_hs92_code", "sitc": "product_sitc_code"}
_FILE = {
    "hs92": "data/raw/hs92/hs92_country_product_year_4.csv",
    "sitc": "data/raw/sitc/sitc_country_product_year_4.csv",
}


def load_clean(classification: str, min_total_trade_usd: float = 1e9) -> pd.DataFrame:
    """Return a cleaned country-product-year DataFrame for one classification.

    Output columns: iso3, product, year, export_value, import_value,
    distance, pci.
    """
    if classification not in _FILE:
        raise ValueError(f"unknown classification: {classification!r}")
    code_col = _CODE_COL[classification]
    path = (ROOT / _FILE[classification]).as_posix()
    ch99 = f"AND TRY_CAST({code_col} AS INTEGER) < 9900" if classification == "hs92" else ""

    con = duckdb.connect()
    df = con.execute(f"""
        WITH base AS (
            SELECT country_iso3_code            AS iso3,
                   CAST({code_col} AS VARCHAR)  AS product,
                   CAST(year AS INTEGER)        AS year,
                   CAST(export_value AS DOUBLE) AS export_value,
                   CAST(import_value AS DOUBLE) AS import_value,
                   CAST(distance AS DOUBLE)     AS distance,
                   CAST(pci AS DOUBLE)          AS pci
            FROM read_csv_auto('{path}')
            WHERE export_value IS NOT NULL
              AND import_value IS NOT NULL
              AND distance     IS NOT NULL
              AND NOT (export_value = 0 AND import_value = 0)
              {ch99}
        ),
        tot AS (
            SELECT iso3, year, SUM(export_value + import_value) AS total_trade
            FROM base GROUP BY iso3, year
        )
        SELECT b.iso3, b.product, b.year,
               b.export_value, b.import_value, b.distance, b.pci
        FROM base b
        JOIN tot t USING (iso3, year)
        WHERE t.total_trade >= {min_total_trade_usd}
    """).df()
    con.close()

    df["iso3"] = df["iso3"].astype("category")
    df["product"] = df["product"].astype("category")
    df["year"] = df["year"].astype("int16")
    return df
