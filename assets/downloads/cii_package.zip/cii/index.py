"""
cii/index.py
============
The Consumption Sovereignty Index - Steps 3-5 of the methodology.

    g_cp    = cap_cp * dep_cp                    product-level gap
    CCG_c   = sum_p w_cp * g_cp                  capability-consumption gap
                                                 (Tier-1 proxy for the CES
                                                 foreign-goods preference alpha)
    CII_raw = 1 - CCG_c                          raw index (high = intelligent)
    CII     = within-year z-score of CII_raw     standardised index
    CII_100 = within-year percentile rank        0-100 presentation scale
"""
from __future__ import annotations

import pandas as pd


def compute_index(df: pd.DataFrame) -> pd.DataFrame:
    """Country-year panel: CCG, CII_raw, CII (z-score), CII_100."""
    df = df.copy()
    df["contrib"] = df["w"] * df["cap"] * df["dep"]          # w * g
    df["_imp"] = (df["import_value"] > 0).astype("int32")

    panel = (df.groupby(["iso3", "year"], observed=True, as_index=False)
               .agg(CCG=("contrib", "sum"),
                    n_import_products=("_imp", "sum"),
                    total_imports=("import_value", "sum"),
                    total_exports=("export_value", "sum")))

    panel["CII_raw"] = 1.0 - panel["CCG"]
    grp = panel.groupby("year")["CII_raw"]
    panel["CII"] = (panel["CII_raw"] - grp.transform("mean")) / grp.transform("std")
    panel["CII_100"] = panel.groupby("year")["CII_raw"].rank(pct=True) * 100.0
    return panel


def product_diagnostics(df: pd.DataFrame, top: int = 15) -> pd.DataFrame:
    """Per country-year, the products contributing most to the gap."""
    cols = ["iso3", "year", "product", "import_value", "export_value",
            "density", "simplicity", "cap", "dep", "w"]
    d = df.loc[:, cols].copy()
    d["contrib"] = d["w"] * d["cap"] * d["dep"]
    d = d.sort_values("contrib", ascending=False)
    return (d.groupby(["iso3", "year"], observed=True, group_keys=False)
              .head(top).reset_index(drop=True))
